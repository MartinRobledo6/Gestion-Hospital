<script setup lang="ts">
import { ref, reactive } from 'vue';
import { ProtocoloBuilder, type ProtocoloPayload } from './ProtocoloBuilder';

// Datos de prueba (Paciente y Enfermero)
const pacienteId = ref<number>(102);
const enfermeroId = ref<number>(5);

// -------------------------------------------------------------------
// HU 1.1: REGISTRO DE SIGNOS VITALES
// -------------------------------------------------------------------
const signos = reactive({
  presionArterial: '120/80',
  frecuenciaCardiaca: 80,
  temperatura: 36.5,
  alertaFiebre: false,
  mensajeFeedback: ''
});

const registrarSignos = () => {
  // Regla de Negocio: Alerta si temperatura > 39°C (Escenario 2)
  if (signos.temperatura > 39.0) {
    signos.alertaFiebre = true;
    signos.mensajeFeedback = `⚠️ ALERTA: Temperatura de ${signos.temperatura}°C supera el límite de 39°C. Se emite notificación de alta prioridad al médico.`;
  } else {
    signos.alertaFiebre = false;
    signos.mensajeFeedback = '✅ Signos vitales dentro de rangos normales. Registro guardado en la historia clínica.';
  }
};

// -------------------------------------------------------------------
// HU 1.2: ADMINISTRACIÓN DE MEDICACIÓN
// -------------------------------------------------------------------
const medicacionFeedback = ref<string>('');

const administrarMedicacion = (estado: 'Administrada' | 'Omitida') => {
  if (estado === 'Administrada') {
    medicacionFeedback.value = '✅ Dosis marcada como "Administrada". Se emitió evento para descontar 1 unidad del inventario.';
  } else {
    medicacionFeedback.value = '⚠️ Dosis marcada como "Omitida". Registrado en el sistema.';
  }
};

// -------------------------------------------------------------------
// HU 2.1: GENERACIÓN DE PROTOCOLOS (BUILDER)
// -------------------------------------------------------------------
const protocoloActual = ref<ProtocoloPayload | null>(null);

const cargarPresetProtocolo = (tipo: 'pre-op' | 'respiratorio') => {
  const builder = new ProtocoloBuilder(pacienteId.value);

  if (tipo === 'pre-op') {
    builder.buildPreQuirurgico();
  } else if (tipo === 'respiratorio') {
    builder.buildRespiratorio();
  }

  protocoloActual.value = builder.getPayload();
};
</script>

<template>
  <div style="padding: 20px; max-width: 900px; margin: 0 auto; font-family: sans-serif;">
    <h1>Módulo de Atención y Enfermería</h1>
    <p><strong>Paciente ID:</strong> {{ pacienteId }} | <strong>Enfermero ID:</strong> {{ enfermeroId }}</p>

    <hr />

    <!-- HU 1.1 -->
    <section style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
      <h2>HU 1.1 - Control y Registro de Signos Vitales</h2>
      <form @submit.prevent="registrarSignos">
        <div style="margin-bottom: 10px;">
          <label>Presión Arterial: </label>
          <input v-model="signos.presionArterial" type="text" required />
        </div>
        <div style="margin-bottom: 10px;">
          <label>Frecuencia Cardíaca (bpm): </label>
          <input v-model.number="signos.frecuenciaCardiaca" type="number" required />
        </div>
        <div style="margin-bottom: 10px;">
          <label>Temperatura (°C): </label>
          <input v-model.number="signos.temperatura" type="number" step="0.1" required />
        </div>
        <button type="submit">Registrar Signos Vitales</button>
      </form>

      <div 
        v-if="signos.mensajeFeedback" 
        :style="{ marginTop: '10px', padding: '10px', borderRadius: '5px', backgroundColor: signos.alertaFiebre ? '#ffdddd' : '#ddffdd', color: signos.alertaFiebre ? '#a00000' : '#006000' }"
      >
        {{ signos.mensajeFeedback }}
      </div>
    </section>

    <!-- HU 1.2 -->
    <section style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
      <h2>HU 1.2 - Administración de Medicación Prescrita</h2>
      <p><strong>Indicación Activa:</strong> Ibuprofeno 400mg cada 8 horas (Dosis 14:00 hs)</p>
      <button @click="administrarMedicacion('Administrada')" style="margin-right: 10px;">
        Confirmar "Administrada"
      </button>
      <button @click="administrarMedicacion('Omitida')">
        Marcar "Omitida"
      </button>

      <p v-if="medicacionFeedback" style="margin-top: 10px; font-weight: bold;">
        {{ medicacionFeedback }}
      </p>
    </section>

    <!-- HU 2.1 -->
    <section style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
      <h2>HU 2.1 - Protocolos de Atención (Patrón Builder)</h2>
      <p>Seleccionar motivo de ingreso para generar tareas inmediatas:</p>
      
      <button @click="cargarPresetProtocolo('pre-op')" style="margin-right: 10px;">
        Cargar Builder: Pre-Quirúrgico
      </button>
      <button @click="cargarPresetProtocolo('respiratorio')">
        Cargar Builder: Infección Respiratoria
      </button>

      <div v-if="protocoloActual" style="margin-top: 15px; border: 1px solid #ccc; padding: 10px; border-radius: 5px; background: white;">
        <h3>{{ protocoloActual.tipoProtocolo }}</h3>
        <ul>
          <li v-for="(tarea, idx) in protocoloActual.tareas" :key="idx">
            {{ tarea.descripcion }}
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>